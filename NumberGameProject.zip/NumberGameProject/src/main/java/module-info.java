module com.example.numbergameproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.numbergameproject to javafx.fxml;
    exports com.example.numbergameproject;
}